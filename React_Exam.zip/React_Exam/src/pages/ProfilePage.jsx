import { useState } from 'react'
import { assetUrl, uploadAvatar } from '../api'

export default function ProfilePage({ user, sessions, joinedIds, onUserChange, onBack, onCreateSession }) {
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const hosted = sessions.filter((s) => s.host === user.nick)
  const joined = sessions.filter((s) => joinedIds.includes(s.id))
  const avatar = assetUrl(user.avatarUrl)

  const onFile = async (event) => {
    const file = event.target.files?.[0]
    if (!file) return
    if (!file.type.startsWith('image/')) return setError('Оберіть файл зображення.')
    if (file.size > 5 * 1024 * 1024) return setError('Максимальний розмір файлу — 5 МБ.')
    setError('')
    setBusy(true)
    try {
      const url = await uploadAvatar(file)
      onUserChange({ ...user, avatarUrl: url })
    } catch (e) {
      setError(e.message || 'Помилка завантаження аватара')
    } finally {
      setBusy(false)
      event.target.value = ''
    }
  }

  return (
    <section className="profile-page">
      <div className="page-heading">
        <div>
          <span className="eyebrow">GAMECLUB ACCOUNT</span>
          <h1>Профіль гравця</h1>
          <p>Керуйте своїм акаунтом та аватаром.</p>
        </div>
        <span className="profile-status"><i /> Акаунт активний</span>
      </div>

      <div className="profile-card">
        <div className="profile-avatar-wrap">
          {avatar
            ? <img className="profile-avatar" src={avatar} alt="Аватар профілю" />
            : <div className="profile-avatar profile-avatar-placeholder">{(user.nick || '?')[0].toUpperCase()}</div>}
          <label className="btn primary upload-btn">
            {busy ? 'Завантаження...' : 'Змінити аватар'}
            <input type="file" accept="image/*" onChange={onFile} disabled={busy} />
          </label>
          <small>PNG, JPG або GIF · до 5 МБ</small>
        </div>

        <div className="profile-details">
          <span className="eyebrow">ОСОБИСТА ІНФОРМАЦІЯ</span>
          <h2>{user.nick}</h2>
          <p className="profile-email">{user.email || 'Email не вказано'}</p>
          {user.bio && <p className="profile-bio">{user.bio}</p>}
          <div className="profile-info-row"><span>Ім'я користувача</span><b>{user.nick}</b></div>
          <div className="profile-info-row"><span>ID акаунта</span><b>{user.id || '—'}</b></div>
          <div className="profile-info-row"><span>Статус</span><b className="online-text">Онлайн-профіль</b></div>
          {error && <div className="err profile-error">{error}</div>}
          <button className="btn" onClick={onBack}>Повернутися до ігор</button>
        </div>
      </div>

      <div className="profile-stats">
        <div className="pstat"><b>{hosted.length}</b><span>Створено сесій</span></div>
        <div className="pstat"><b>{joined.length}</b><span>Приєднано сесій</span></div>
        <div className="pstat"><b>{hosted.length + joined.length}</b><span>Усього активностей</span></div>
      </div>

      <div className="profile-sessions">
        <div className="head-row">
          <span className="eyebrow">МОЇ СЕСІЇ</span>
          <button className="btn primary sm" onClick={() => onCreateSession()}>+ Створити</button>
        </div>
        <div className="list">
          {[...hosted, ...joined].map((s) => (
            <div className="row" key={s.id}>
              <span className="badge">{s.game}</span>
              <div className="grow"><b>{s.title}</b><br /><small>Хост: {s.host}</small></div>
              <div className="bar"><i style={{ width: `${(s.cur / s.max) * 100}%` }} /></div>
              <b>{s.cur}/{s.max}</b>
            </div>
          ))}
          {!hosted.length && !joined.length && <div className="empty">Ви ще не брали участі в сесіях.</div>}
        </div>
      </div>

      <div className="profile-note">
        <b>Безпека сесії</b>
        <span>Якщо access-токен закінчиться, застосунок автоматично запросить новий через auth/refresh та повторить запит.</span>
      </div>
    </section>
  )
}
