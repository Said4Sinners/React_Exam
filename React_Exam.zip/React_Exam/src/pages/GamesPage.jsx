import { useMemo, useState } from 'react'

const SORTS = [
  ['online', 'За онлайном'],
  ['name', 'За назвою'],
]

function GameModal({ game, sessions, onClose, onCreate }) {
  const related = sessions.filter((s) => s.game === game.name)
  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal game-modal" onClick={(e) => e.stopPropagation()}>
        <button className="close" onClick={onClose}>×</button>
        <div className="game-cover" style={{ background: `linear-gradient(135deg, ${game.c[0]}, ${game.c[1]})` }}>
          <span className="letter">{game.name[0]}</span>
          <h3>{game.name}</h3>
        </div>
        <div className="game-meta">
          <span className="badge">{game.genre}</span>
          <span className="game-online"><span className="dot" />{game.online} у грі</span>
        </div>
        {game.description && <p className="game-desc">{game.description}</p>}

        <div className="game-sessions">
          <span className="eyebrow">АКТИВНІ СЕСІЇ · {related.length}</span>
          {related.length ? related.map((s) => (
            <div className="game-session-row" key={s.id}>
              <span><b>{s.title}</b><small>Хост: {s.host}</small></span>
              <b>{s.cur}/{s.max}</b>
            </div>
          )) : <small className="muted">Поки немає сесій — створи першу!</small>}
        </div>

        <button className="btn primary wide" onClick={() => onCreate(game.name)}>Створити сесію</button>
      </div>
    </div>
  )
}

export default function GamesPage({ games, loading, demo, sessions, onCreateSession }) {
  const [genre, setGenre] = useState('Усі')
  const [q, setQ] = useState('')
  const [sort, setSort] = useState('online')
  const [selected, setSelected] = useState(null)

  const genres = useMemo(() => ['Усі', ...new Set(games.map((g) => g.genre))], [games])
  const shown = useMemo(() => {
    const list = games.filter(
      (g) => (genre === 'Усі' || g.genre === genre) && g.name.toLowerCase().includes(q.toLowerCase()),
    )
    return list.sort((a, b) => (sort === 'name' ? a.name.localeCompare(b.name) : b.online - a.online))
  }, [games, genre, q, sort])

  const totalOnline = games.reduce((a, g) => a + g.online, 0)

  return (
    <section className="games-page">
      <div className="page-heading">
        <div>
          <span className="eyebrow">GAMECLUB LIBRARY</span>
          <h1>Бібліотека ігор</h1>
          <p>Обери гру, подивись активні сесії та збери команду.</p>
        </div>
        <div className="stat-box">
          <b>{games.length}</b><span>ігор</span>
          <b>{totalOnline.toLocaleString('uk-UA')}</b><span>у грі зараз</span>
        </div>
      </div>

      {demo && !loading && (
        <div className="notice">Сервер ігор недоступний — показано демо-дані.</div>
      )}

      <div className="toolbar">
        <div className="chips">
          {genres.map((g) => (
            <button key={g} className={'chip' + (genre === g ? ' active' : '')} onClick={() => setGenre(g)}>
              <b>{g === 'Усі' ? games.length : games.filter((x) => x.genre === g).length}</b>{g}
            </button>
          ))}
        </div>
        <select className="search select" value={sort} onChange={(e) => setSort(e.target.value)}>
          {SORTS.map(([k, label]) => <option key={k} value={k}>{label}</option>)}
        </select>
        <input className="search" placeholder="Пошук гри..." value={q} onChange={(e) => setQ(e.target.value)} />
      </div>

      {loading ? (
        <div className="cards">
          {Array.from({ length: 8 }, (_, i) => <div className="mode skeleton" key={i} />)}
        </div>
      ) : (
        <div className="cards">
          {shown.map((g) => (
            <div className="mode" key={g.id} style={{ background: `linear-gradient(135deg, ${g.c[0]}, ${g.c[1]})` }} onClick={() => setSelected(g)}>
              <span className="play">ДЕТАЛІ</span>
              <span className="letter">{g.name[0]}</span>
              <h3>{g.name}</h3>
              <small><span className="dot" />{g.online} у грі · {g.genre}</small>
            </div>
          ))}
        </div>
      )}
      {!loading && !shown.length && <div className="empty">Нічого не знайдено</div>}

      {selected && (
        <GameModal
          game={selected}
          sessions={sessions}
          onClose={() => setSelected(null)}
          onCreate={(name) => { setSelected(null); onCreateSession(name) }}
        />
      )}
    </section>
  )
}
