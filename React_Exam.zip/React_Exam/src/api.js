import axios from 'axios'

// Базова адреса API (Azure). Можна перевизначити через .env -> VITE_API_URL
export const API_URL = (
  import.meta.env.VITE_API_URL ||
  'https://readyplayerone-d5cehnc2b0dreacv.germanywestcentral-01.azurewebsites.net'
).replace(/\/$/, '')

// Єдиний axios-інстанс. withCredentials потрібен, щоб браузер надсилав refresh-cookie
export const api = axios.create({
  baseURL: API_URL,
  withCredentials: true,
  headers: { 'Content-Type': 'application/json' },
})

let accessToken = ''
let refreshPromise = null

export function setAccessToken(token) { accessToken = token || '' }
export function clearAccessToken() { accessToken = '' }

const pickToken = (d) => d?.accessToken ?? d?.AccessToken ?? ''

// Текст помилки з відповіді сервера (ProblemDetails / ValidationProblem / Identity errors)
export function errorMessage(error, fallback) {
  const d = error?.response?.data
  if (!d) return error?.response ? fallback : 'Сервер недоступний. Перевірте з’єднання.'
  if (typeof d === 'string' && d.trim()) return d
  const errors = d.errors ?? d.Errors
  if (Array.isArray(errors)) {
    const text = errors.map((e) => (typeof e === 'string' ? e : e.description ?? e.Description ?? '')).filter(Boolean).join(', ')
    if (text) return text
  } else if (errors && typeof errors === 'object') {
    const text = Object.values(errors).flat().join(', ')
    if (text) return text
  }
  return d.message ?? d.Message ?? d.detail ?? d.title ?? fallback
}

// POST /api/Auth/refresh — один спільний запит на всі паралельні 401
function refreshAccessToken() {
  if (!refreshPromise) {
    // окремий виклик axios без інтерсепторів, щоб не зациклитись
    refreshPromise = axios
      .post(`${API_URL}/api/Auth/refresh`, null, { withCredentials: true })
      .then(({ data }) => {
        const token = pickToken(data)
        if (!token) throw new Error('Сервер не повернув access-токен')
        accessToken = token
        return token
      })
      .catch((e) => {
        accessToken = ''
        throw e
      })
      .finally(() => { refreshPromise = null })
  }
  return refreshPromise
}

// Додаємо Bearer-токен до кожного запиту
api.interceptors.request.use((config) => {
  if (accessToken) config.headers.Authorization = `Bearer ${accessToken}`
  return config
})

// Якщо 401 — оновлюємо токен і повторюємо запит один раз
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const original = error.config
    const status = error.response?.status
    const isAuthCall = /\/api\/Auth\/(login|register|refresh|logout)/i.test(original?.url || '')
    if (original && status === 401 && !original._retry && !isAuthCall) {
      original._retry = true
      try {
        await refreshAccessToken()
        original.headers.Authorization = `Bearer ${accessToken}`
        return api(original)
      } catch {
        clearAccessToken()
      }
    }
    return Promise.reject(error)
  },
)

// Повний URL для картинок (аватар може прийти як відносний шлях)
export const assetUrl = (url) => (!url ? null : url.startsWith('http') ? url : `${API_URL}${url}`)

/* ---------------- Auth ---------------- */

// POST /api/Auth/register  { userName, email, password }
export async function register(userName, email, password) {
  try {
    await api.post('/api/Auth/register', { userName, email, password })
  } catch (e) {
    throw new Error(errorMessage(e, 'Не вдалося зареєструвати акаунт'))
  }
}

// POST /api/Auth/login  { email, password } -> { accessToken, expiresAt }
export async function login(email, password) {
  try {
    const { data } = await api.post('/api/Auth/login', { email, password })
    const token = pickToken(data)
    if (!token) throw new Error('Сервер не повернув access-токен')
    setAccessToken(token)
  } catch (e) {
    throw new Error(e.response ? errorMessage(e, 'Невірний email або пароль') : e.message)
  }
}

// POST /api/Auth/logout
export async function logout() {
  try { await api.post('/api/Auth/logout') } catch { /* ignore */ }
  clearAccessToken()
}

// GET /api/Auth/me -> { id, nick, email, avatarUrl, bio } або null
export async function fetchProfile() {
  try {
    const { data: d } = await api.get('/api/Auth/me')
    return {
      id: d.userId ?? d.UserId ?? d.id ?? d.Id,
      nick: d.displayName ?? d.DisplayName ?? d.userName ?? d.UserName ?? 'Гравець',
      email: d.email ?? d.Email ?? '',
      avatarUrl: d.avatarUrl ?? d.AvatarUrl ?? null,
      bio: d.bio ?? d.Bio ?? '',
    }
  } catch {
    return null
  }
}

/* ---------------- Profile (немає в Swagger!) ---------------- */

// Увага: ендпойнта /api/profile/avatar у v1.json немає — запит може повернути 404
export async function uploadAvatar(file) {
  const body = new FormData()
  body.append('avatar', file)
  try {
    const { data } = await api.post('/api/profile/avatar', body, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
    return data?.avatarUrl ?? data?.AvatarUrl ?? null
  } catch (e) {
    throw new Error(errorMessage(e, 'Не вдалося завантажити аватар'))
  }
}
